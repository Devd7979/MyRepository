using NXOpen;
using System;
using NXOpen.UF;
using NXOpen.Assemblies;
using System.Collections.Generic;

public class Program
{
    private static Session theSession;
    private static UFSession theUfSession;
    private static UI theUI;

    public static int assemblyLevel = 0;
    public static List<Component> allComponents = new List<Component>();

    public Program()
    {
        theSession = Session.GetSession();
        theUI = UI.GetUI();
        theUfSession = UFSession.GetUFSession();

    }
    public static void Main()
    {
        Program theProgram = new Program();

        Part workPart = theSession.Parts.Work;
        AssemblyStructure.UIMain();

    }

    public static int GetUnloadOption(string arg)
    {
        //Unloads the image explicitly, via an unload dialog
        //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);

        //Unloads the image immediately after execution within NX
        return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);

        //Unloads the image when the NX session terminates
        // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
    }


}