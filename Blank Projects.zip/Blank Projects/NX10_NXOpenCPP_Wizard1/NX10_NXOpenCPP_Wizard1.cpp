//NX10_NXOpenCPP_Wizard1

// Mandatory UF Includes
#include <uf.h>
#include <uf_object_types.h>

// Internal Includes
#include <NXOpen/ListingWindow.hxx>
#include <NXOpen/NXMessageBox.hxx>
#include <NXOpen/Selection.hxx>
#include <NXOpen/UI.hxx>

// Internal+External Includes
#include <NXOpen/Annotations.hxx>
#include <NXOpen/Assemblies_Component.hxx>
#include <NXOpen/Assemblies_ComponentAssembly.hxx>
#include <NXOpen/Body.hxx>
#include <NXOpen/BodyCollection.hxx>
#include <NXOpen/Face.hxx>
#include <NXOpen/Line.hxx>
#include <NXOpen/NXException.hxx>
#include <NXOpen/NXObject.hxx>
#include <NXOpen/Part.hxx>
#include <NXOpen/PartCollection.hxx>
#include <NXOpen/Session.hxx>

// Std C++ Includes
#include <iostream>
#include <sstream>

using namespace NXOpen;
using std::string;
using std::exception;
using std::stringstream;
using std::endl;
using std::cout;
using std::cerr;

//------------------------------------------------------------------------------
// Open C error handling
//------------------------------------------------------------------------------
#define UF_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int report_error( char *file, int line, char *call, int code)
{
    if (code) 
	{

		stringstream errmsg;
		errmsg << "Error " << code << " in " << file << " at line " << line << endl;
		errmsg << call << endl;
		UI::GetUI()->NXMessageBox()->Show("Open C Error", NXOpen::NXMessageBox::DialogTypeError, errmsg.str().c_str());
		throw NXOpen::NXException::Create(code);
	}
    return(code);
}

//------------------------------------------------------------------------------
// NXOpen c++ test class 
//------------------------------------------------------------------------------
class MyClass
{
    // class members
public:
    static Session *theSession;
    static UI *theUI;

    MyClass();
    ~MyClass();

	void do_it();
	void print(const NXString &);
	void print(const string &);
	void print(const char*);
	TaggedObject* select_by_mask();
	TaggedObject* select_by_type();
	std::vector< NXOpen::TaggedObject * > select_any_objects();

private:
	Part *workPart, *displayPart;
	Selection *selmgr;
	NXMessageBox *mb;
	ListingWindow *lw;
};

//------------------------------------------------------------------------------
// Initialize static variables
//------------------------------------------------------------------------------
Session *(MyClass::theSession) = NULL;
UI *(MyClass::theUI) = NULL;

//------------------------------------------------------------------------------
// Constructor 
//------------------------------------------------------------------------------
MyClass::MyClass()
{
	// Initialize the Open C API environment */
	UF_CALL( UF_initialize() );

	// Initialize the NX Open C++ API environment
	MyClass::theSession = NXOpen::Session::GetSession();
	MyClass::theUI = UI::GetUI();
	selmgr = theUI->SelectionManager();
	mb = theUI->NXMessageBox();
	lw = theSession->ListingWindow();

    workPart = theSession->Parts()->Work();
	displayPart = theSession->Parts()->Display();
	
}

//------------------------------------------------------------------------------
// Destructor
//------------------------------------------------------------------------------
MyClass::~MyClass()
{
	UF_CALL( UF_terminate() );
}

//------------------------------------------------------------------------------
// Print string to listing window or stdout
//------------------------------------------------------------------------------
void MyClass::print(const NXString &msg)
{
	if(! lw->IsOpen() ) lw->Open();
	lw->WriteLine(msg);
}
void MyClass::print(const string &msg)
{
	if(! lw->IsOpen() ) lw->Open();
	lw->WriteLine(msg);
}
void MyClass::print(const char * msg)
{
	if(! lw->IsOpen() ) lw->Open();
	lw->WriteLine(msg);
}

//------------------------------------------------------------------------------
// Selection with mask
//------------------------------------------------------------------------------
TaggedObject* MyClass::select_by_mask()
{
	NXString message("Select an object by mask:");
	NXString title("Select object");
	Selection::SelectionScope scope = Selection::SelectionScopeUseDefault;
	Selection::SelectionAction action = Selection::SelectionActionClearAndEnableSpecific;
	bool include_features = 0;
	bool keep_highlighted = 0;

	// Define the mask triple(s), see also uf_object_types.h.
	// Uncomment or combine the desired mask triples
	std::vector<Selection::MaskTriple> maskArray(1);
	maskArray[0] = Selection::MaskTriple( UF_solid_type, UF_solid_body_subtype, 0 ); // Bodies
	/*
	maskArray[0] = Selection::MaskTriple( UF_solid_type, UF_all_subtype, UF_UI_SEL_FEATURE_ANY_FACE); // Faces
	maskArray[0] = Selection::MaskTriple( UF_solid_type, UF_all_subtype, UF_UI_SEL_FEATURE_ANY_EDGE); // Edges
	maskArray[0] = Selection::MaskTriple( UF_component_type, 0, 0 ); // Components
	maskArray[0] = Selection::MaskTriple( UF_line_type, 0, 0 ); // Lines
	maskArray[0] = Selection::MaskTriple( UF_drafting_entity_type, 0, 0 ); // Drafting objects
	*/
	Point3d cursor;
	TaggedObject *object;

	// Select objects using filter defined by maskArray triples
	Selection::Response res = selmgr->SelectTaggedObject(
			message, title, scope, action, include_features,
            keep_highlighted, maskArray, &object, &cursor );

	if( res == Selection::ResponseObjectSelected )
	{
		return object;
	}
	return 0;
}

//------------------------------------------------------------------------------
// Selection with type array
//------------------------------------------------------------------------------
TaggedObject* MyClass::select_by_type()
{
	NXString message("Select an object by type:");
	NXString title("Select object");
	Selection::SelectionScope scope = Selection::SelectionScopeUseDefault;
	bool keep_highlighted = 0;

	// Define the mask triple(s), see also uf_object_types.h.
	// Uncomment or combine the desired types
	std::vector<Selection::SelectionType> typeArray(1);
	typeArray[0] = Selection::SelectionTypeAll;
	/*
	typeArray[0] = Selection::SelectionTypeFeatures;
	typeArray[0] = Selection::SelectionTypeCurves;
	typeArray[0] = Selection::SelectionTypeFaces;
	typeArray[0] = Selection::SelectionTypeEdges;
	typeArray[0] = Selection::SelectionTypeCurvesAndEdges;
	*/
	Point3d cursor;
	TaggedObject *object;

	// Select objects using filter defined by type array
	Selection::Response res = selmgr->SelectTaggedObject(
			message, title, scope, keep_highlighted, 
			typeArray, &object, &cursor );

	if( res == Selection::ResponseObjectSelected )
	{
		return object;
	}
	return 0;
}

//------------------------------------------------------------------------------
// Selection any objects
//------------------------------------------------------------------------------
std::vector< NXOpen::TaggedObject * > MyClass::select_any_objects()
{
	NXString message("Select any objects:");
	NXString title("Select objects");
	Selection::SelectionScope scope = Selection::SelectionScopeUseDefault;
	bool include_features = 0;	
	bool keep_highlighted = 0;
	std::vector< NXOpen::TaggedObject * > objectArray;

	// Select any object array
	Selection::Response res = selmgr->SelectTaggedObjects(
			message, title, scope, include_features, 
			keep_highlighted, objectArray );

	return objectArray;
}

//------------------------------------------------------------------------------
// Do something
//------------------------------------------------------------------------------
void MyClass::do_it()
{
	TaggedObject* masked_obj = select_by_mask();
	TaggedObject* typed_obj = select_by_type();
	std::vector< NXOpen::TaggedObject * > any_objs = select_any_objects();

	// TODO: add your code here
	
}

//------------------------------------------------------------------------------
// Entry point(s) for unmanaged internal NXOpen C/C++ programs
//------------------------------------------------------------------------------
//  Explicit Execution
extern "C" DllExport void ufusr( char *parm, int *returnCode, int rlen )
{
    try
    {
		// Create NXOpen C++ class instance
		MyClass *theMyClass;
		theMyClass = new MyClass();
		theMyClass->do_it();
		delete theMyClass;
	}
    catch (const NXException& e1)
    {
		UI::GetUI()->NXMessageBox()->Show("NXException", NXOpen::NXMessageBox::DialogTypeError, e1.Message());
    }
	catch (const exception& e2)
    {
		UI::GetUI()->NXMessageBox()->Show("Exception", NXOpen::NXMessageBox::DialogTypeError, e2.what());
    }
	catch (...)
    {
		UI::GetUI()->NXMessageBox()->Show("Exception", NXOpen::NXMessageBox::DialogTypeError, "Unknown Exception.");
    }
}


//------------------------------------------------------------------------------
// Unload Handler
//------------------------------------------------------------------------------
extern "C" DllExport int ufusr_ask_unload()
{
	return (int)NXOpen::Session::LibraryUnloadOptionImmediately;
}


