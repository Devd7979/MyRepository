========================================================================
    NX Open API : NX10_Open_Wizard1 Project Overview
========================================================================

The NX10 Open AppWizard has created this NX10_Open_Wizard1 project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.
*.vcproj
    This is the main project file for projects generated using an Application Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.


This is a sample template file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

/////////////////////////////////////////////////////////////////////////////
